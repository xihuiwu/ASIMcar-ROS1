#include "subfunctions.h"

#include <iostream>
#include <queue>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>
#include <vector>

#include "opencv2/core.hpp"
#include "opencv2/highgui.hpp"
#include "opencv2/calib3d.hpp"
#include "opencv2/cudawarping.hpp"
#include "opencv2/cudaimgproc.hpp"
#include "opencv2/cudaarithm.hpp"

using namespace cv;
using namespace std;

Mat frame(1080, 1920, CV_8UC3);
double dataK[9] = {797.291347853076, 0.0, 954.0911522248246, 0.0, 797.7486635926731, 524.5785087770129 ,0.0, 0.0, 1.0};
double datanewK[9] = {797.291347853076/4, 0.0, 954.0911522248246, 0.0, 797.7486635926731/4, 524.5785087770129 ,0.0, 0.0, 1.0};
double dataD[4] = {-0.022046185426876273, -0.0014811900456108225, -0.002085499019587609, 0.0005973311977065658};
Mat K = Mat(3,3,CV_64FC1,dataK);
Mat D = Mat(4,1,CV_64FC1,dataD);
Mat newK = Mat(3,3,CV_64FC1,datanewK);
Mat M = getStructuringElement(MORPH_RECT, Size(3, 3), Point(1, 1));


double sum(Mat pts){
	double ave;
	for(int i = 0; i < pts.rows; i++){
		ave += pts.at<int>(i,0);
	}
	ave = ave/pts.rows;
	if (ave >= 0 && ave <=799){
		return ave;
	}
	else{
		return 0.0;
	}
}


void * capture(void *){
	VideoCapture cap;
	int deviceID = 1;
	int apiID = cv::CAP_ANY;

	cap.open(deviceID + apiID);
	if (!cap.isOpened()){
		cerr << "Unable to open camera\n";
		return 0;
	}
	
	cap.set(CV_CAP_PROP_FRAME_WIDTH, 1920);
	cap.set(CV_CAP_PROP_FRAME_HEIGHT, 1080);

	while (true){
		cap.read(frame);
	}
}


int main(void){
	pthread_t thread2;
	pthread_create(&thread2, NULL, capture, NULL);
	//pthread_join(thread2,NULL);

	usleep(2000000);

	// Define map matrix
	//fisheye::estimateNewCameraMatrixForUndistortRectify(K,D,frame.size(),Matx33d::eye(),newK,1);
	Mat mapx, mapy;
	fisheye::initUndistortRectifyMap(K,D,Matx33d::eye(),newK,frame.size(),CV_32FC1,mapx,mapy);
	cuda::GpuMat mapx_gpu, mapy_gpu;
	mapx_gpu.upload(mapx);
	mapy_gpu.upload(mapy);

	// Corp
	Point corners[4];
	/*corners[0] = Point(960,580);
	corners[1] = Point(1170,580);
	corners[2] = Point(1540,690);
	corners[3] = Point(960,690);*/
	corners[0] = Point(750,580);
	corners[1] = Point(1170,580);
	corners[2] = Point(1540,690);
	corners[3] = Point(380,690);
	const Point* corner_list[1] = {corners};
	cv::Mat mask(1080,1920,CV_8UC3, cv::Scalar(0,0,0));
	int num_points = 4;
	fillPoly( mask, corner_list, &num_points, 1, cv::Scalar( 255, 255, 255 ), 8);
	cuda::GpuMat mask_gpu;
	mask_gpu.upload(mask);

	// Define perspective transform matrix
	Point2f source_points[4];
	/*source_points[0] = Point2f(700,580);
	source_points[1] = Point2f(1220,580);
	source_points[2] = Point2f(1540,690);
	source_points[3] = Point2f(380,690);*/
	source_points[0] = Point(750,580);
	source_points[1] = Point(1170,580);
	source_points[2] = Point(1540,690);
	source_points[3] = Point(380,690);
	Point2f dest_points[4];
	/*dest_points[0] = Point2f(0,0);
	dest_points[1] = Point2f(800,0);
	dest_points[2] = Point2f(700,400);
	dest_points[3] = Point2f(100,400);*/
	dest_points[0] = Point2f(100,0);
	dest_points[1] = Point2f(700,0);
	dest_points[2] = Point2f(685,400);
	dest_points[3] = Point2f(115,400);
	Mat perspectiveM = getPerspectiveTransform(source_points, dest_points);
 	
 	// Define HSL white range
	Scalar low_white = Scalar(0, 180, 0);
	Scalar up_white = Scalar(255, 255, 255);

	for(;;){
		// Undistort frame
		cuda::GpuMat frame_gpu, frame_undistort_gpu;
		frame_gpu.upload(frame);
		cuda::remap(frame_gpu, frame_undistort_gpu, mapx_gpu, mapy_gpu, INTER_LINEAR, BORDER_CONSTANT);
		
		// Corp
		cuda::GpuMat frame_corp_gpu;
		cuda::bitwise_and(frame_undistort_gpu, mask_gpu, frame_corp_gpu);
		
		// Perspective Transfrorm
		cuda::GpuMat lane_region_gpu;
		cuda::warpPerspective(frame_corp_gpu, lane_region_gpu, perspectiveM, Size(800,400));
		
		// Color threshold
		cuda::GpuMat lane_region_hls_gpu;
		cuda::cvtColor(lane_region_gpu, lane_region_hls_gpu, CV_BGR2HLS);
		Mat lane_region_hls(lane_region_hls_gpu), lane_hls;
		inRange(lane_region_hls,low_white,up_white,lane_hls); // lane_hls value 0-255

		// Erosion
		//Mat lane_hls_erosion;
		//erode(lane_hls, lane_hls_erosion, M);

		/*
		// Center Points
		vector<double> center_x;
		vector<double> center_y;
		for(int i = 0; i < 10; i++){
			Mat ind;
			findNonZero(lane_hls.row((i+1)*20-1), ind);
			//cout << ind << endl;
			double result = sum(ind);
			if (result > 0){
				center_x.push_back(result);
				center_y.push_back((i+1)*20);
				//cout << result << "," << (i+1)*20<< endl;
			}
		}
		
		// Polyfit
		vector<double> a = polynomialfit(center_y, center_x, 2);
		//cout << a[0] << " " << a[1] << " " << a[2] << endl;
		
		// Center Deviation
		double dx = a[0]*399*399 + a[1]*399 + a[2] - 400;
		*/

		// Show frame
		Mat frame_undistort(frame_undistort_gpu);
		namedWindow("frame", WINDOW_NORMAL);
		resizeWindow("frame", 800, 600);
		imshow("frame", frame_undistort);
		Mat frame_corp(lane_region_gpu);
		namedWindow("corp", WINDOW_NORMAL);
		resizeWindow("corp", 800, 600);
		imshow("corp", frame_corp);
		imshow("Lane", lane_hls);
		int key = waitKey(30);
		if (key == 's'){
			imwrite("undistort.jpg", frame_undistort);
			imwrite("lane_region.jpg", frame_corp);
			imwrite("lane_threshold.jpg", lane_hls);
		}
	}
	return 0;
}
