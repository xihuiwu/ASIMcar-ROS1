g++ -std=c++11 -fpermissive -pthread lane_detection_cuda.cpp -o lane_detection_cuda `pkg-config --cflags --libs opencv`
