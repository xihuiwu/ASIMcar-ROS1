#!/usr/bin/env python
from imutils.video import WebcamVideoStream
import imutils
import rospy
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import time

port = rospy.get_param("/camera_port", "/dev/video1")
vis = rospy.get_param("/visulization", "0")
cameraPipeline = 'v4l2src device=/dev/video1 extra-controls=\"exposure_auto=0, white_balance_temperature_auto=1\" ! jpegdec ! video/x-raw, width=1920, height=1080, framerate=30/1 ! videoconvert ! appsink';

class image_converter:

	def __init__(self):
		self.vs = WebcamVideoStream(cameraPipeline).start()
		
		rospy.init_node('front_cam', anonymous=True)
		self.image_pub1 = rospy.Publisher("/front_cam/fisheye_raw", Image, queue_size=1)
		self.image_pub2 = rospy.Publisher("/front_cam/fisheye_mono", Image, queue_size=1)
		self.bridge = CvBridge()

	def run(self):
		while not rospy.is_shutdown():
			frame = self.vs.read()
			gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
			gray = imutils.resize(gray, width = 720)
			self.image_pub1.publish(self.bridge.cv2_to_imgmsg(frame, "bgr8"))
			self.image_pub2.publish(self.bridge.cv2_to_imgmsg(gray, "mono8"))
			if vis == "1":
				cv2.imshow("Front Camera", frame)
				cv2.waitKey(30)

if __name__ == '__main__':
	try:
		ic = image_converter()
		ic.run()
	except rospy.ROSInterruptException:
		cv2.destroyAllWindows()
		vs.stop()
		pass
	
