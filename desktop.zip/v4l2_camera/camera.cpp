#include <opencv2/highgui.hpp>
#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>

#include <iostream>
#include <stdio.h>
#include <linux/videodev2.h>
#include <linux/ioctl.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

using namespace cv;
using namespace std;

int width = 1920;
int height = 1080;

// Debug image type
string type2str(int type) {
  string r;

  uchar depth = type & CV_MAT_DEPTH_MASK;
  uchar chans = 1 + (type >> CV_CN_SHIFT);

  switch ( depth ) {
    case CV_8U:  r = "8U"; break;
    case CV_8S:  r = "8S"; break;
    case CV_16U: r = "16U"; break;
    case CV_16S: r = "16S"; break;
    case CV_32S: r = "32S"; break;
    case CV_32F: r = "32F"; break;
    case CV_64F: r = "64F"; break;
    default:     r = "User"; break;
  }

  r += "C";
  r += (chans+'0');

  return r;
}


int main(){
	cout<<"Initialization of Camera"<<endl;
	int fd;
	fd = open("/dev/video1", O_RDWR);
	if (fd < 0){
		perror("Failed to open device, OPEN");
		return 1;
	}

	// Retrieve the device's capabilities
	v4l2_capability cap;
	if (ioctl(fd, VIDIOC_QUERYCAP, &cap) < 0){
		perror("Failed to get device capabilities, VIDIOC_QUERYCAP");
		return 1;
	}

	// Setup video format
	v4l2_format format;
	format.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	format.fmt.pix.pixelformat = V4L2_PIX_FMT_SBGGR12;
	//format.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
	format.fmt.pix.width = width;
	format.fmt.pix.height = height;

	if (ioctl(fd, VIDIOC_S_FMT, &format) < 0){
		perror("Device could not set format, VIDIOC_S_FMT");
		return 1;
	}

	// Setup camera parameters
	v4l2_control ctl;
	ctl.id = V4L2_CID_EXPOSURE_AUTO;
	ctl.value = 1;

	if (ioctl(fd, VIDIOC_S_CTRL, &ctl) < 0){
		perror("Device could not set controls, VIDIOC_S_CTRL");
		return 1;
	}

	// Request buffers from the device
	v4l2_requestbuffers bufrequest;
	bufrequest.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	bufrequest.memory = V4L2_MEMORY_MMAP;
	bufrequest.count = 1;

	if (ioctl(fd, VIDIOC_REQBUFS, &bufrequest) < 0){
		perror("Could not request buffer from device, VIDIOC_REQBUFS");
		return 1;
	}

	// Query the buffers
	v4l2_buffer bufquery = {0};
	bufquery.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	bufquery.memory = V4L2_MEMORY_MMAP;
	bufquery.index = 0;

	if(ioctl(fd, VIDIOC_QUERYBUF, &bufquery) < 0){
		perror("Device did not return the buffer information, VIDIOC_QUERYBUF");
		return 1;
	}

	char* buffer = (char*)mmap(
		NULL,
		bufquery.length,
		PROT_READ | PROT_WRITE,
		MAP_SHARED,
		fd,
		bufquery.m.offset);

	if (buffer == MAP_FAILED){
		perror("mmap");
		return 1;
	}

	memset(buffer, 0, bufquery.length);

	// Get a frame
	// Create a new buffer type
	v4l2_buffer bufferinfo;
	memset(&bufferinfo, 0, sizeof(bufferinfo));
	bufferinfo.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
	bufferinfo.memory = V4L2_MEMORY_MMAP;
	bufferinfo.index = 0;

	// Activate streaming
	int type = bufferinfo.type;
	if (ioctl(fd, VIDIOC_STREAMON, &type) < 0){
		perror("Could not start streaming, VIDIOC_STREAMON");
		return 1;
	}

	Mat chs[2];
	int index = 1;
	char full_name[70];

	cout<<"Start Streaming"<<endl;
	/***************************Loop***************************/
	while (true){
		// Queue the buffer
		if (ioctl(fd, VIDIOC_QBUF, &bufferinfo) < 0){
			perror("Could not queue buffer, VIDIOC_QBUF");
			return 1;
		}

		// Dequeue the buffer
		if (ioctl(fd, VIDIOC_DQBUF, &bufferinfo) < 0){
			perror("Could not queue buffer, VIDIOC_DQBUF");
			return 1;
		}

		//cout<<"convert buffer to Mat"<<endl;
		Mat image_buffer(height, width, CV_8UC3, (void*)buffer);
		Mat frame = imdecode(image_buffer,1);

		namedWindow("Fisheye", CV_WINDOW_NORMAL);
		resizeWindow("Fisheye", width/2, height/2);
		imshow("Fisheye", frame);

		//namedWindow("Fisheye_sharp", CV_WINDOW_NORMAL);
		//resizeWindow("Fisheye_sharp", width/4, height/4);
		//imshow("Fisheye_sharp", frame_distorted_white_denoised);

		waitKey(30);

	}

	/***************************Loop End***************************/

	//End stream
	if (ioctl(fd, VIDIOC_STREAMOFF, &type) < 0){
		perror("Could not end streaming, VIDIOC_STREAMOFF");
		return 1;
	}

	close(fd);
	cout<<"End Streaming"<<endl;
	return 0;
}
