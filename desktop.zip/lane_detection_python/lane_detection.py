import numpy as np
import cv2
from scipy import optimize
import math


class lane_detection:

	def __init__(self,
				 lower_white = np.array([0,200,0]),
				 upper_white = np.array([255,255,255]), 
				 lower_yellow = np.array([10,0,100]),
				 upper_yellow = np.array([40,255,255]),
				 pw = 400,
				 ph = 400,
				 binary_low_thr = 150,
				 binary_high_thr = 255,
				 canny_low_thr = 0,
				 canny_high_thr = 225):
		self.lower_white = lower_white
		self.upper_white = upper_white
		self.lower_yellow = lower_yellow
		self.upper_yellow = upper_yellow
		self.pw = pw
		self.ph = ph
		self.source_points = np.array([[734,400],[1169,400],[1920,740],[0,740]],dtype="float32")
		self.dest_points = np.array([[0,0],[self.pw,0],[self.pw,self.ph],[0,self.ph]],dtype="float32")
		self.binary_low_thr = binary_low_thr
		self.binary_high_thr = binary_high_thr
		self.canny_low_thr = canny_low_thr
		self.canny_high_thr = canny_high_thr
		self.L = 0.256
		self.Lfd = 95
		self.z = []

	def perspective_transform(self, frame):
		M = cv2.getPerspectiveTransform(self.source_points,self.dest_points)
		perspective_frame = cv2.warpPerspective(frame,M,(self.pw,self.ph))

		return perspective_frame

	def convert_binary_image(self, perspective_frame):
		frame_hls = cv2.cvtColor(perspective_frame, cv2.COLOR_BGR2HLS)
		mask1 = cv2.inRange(frame_hls,self.lower_white,self.upper_white)
		#mask2 = cv2.inRange(frame_hls,self.lower_yellow,self.upper_yellow)
		#mask = mask1 + mask2
		frame_mask = cv2.bitwise_and(perspective_frame,perspective_frame,mask= mask1)
		frame_gray = cv2.cvtColor(frame_mask,cv2.COLOR_BGR2GRAY)
		ret,frame_binary = cv2.threshold(frame_gray,self.binary_low_thr,self.binary_high_thr,cv2.THRESH_BINARY)

		# Lane frame in binary format
		return frame_binary

	def is_contour_circle(self, cnt):
		peri = cv2.arcLength(cnt, True)
		approx = cv2.approxPolyDP(cnt, 0.02*peri, True)

		return len(approx) > 8


	def canny_frame(self, perspective_frame):
		mask = np.ones(perspective_frame.shape[:2], dtype="uint8")
		frame_edge = cv2.Canny(perspective_frame, self.canny_low_thr, self.canny_high_thr)
		_, cnts, _ = cv2.findContours(frame_edge.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
		for cnt in cnts:
			if self.is_contour_circle(cnt):
				cv2.drawContours(mask, [cnt], -1, 0, -1)
		frame_dege = cv2.bitwise_and(frame_edge, frame_edge, mask=mask)

		return frame_edge


	def func(self, y):
		return (self.pw - 1 - y)**2 + (self.ph/2 - 1 - self.z[0]*y**2 - self.z[1]*y - self.z[2])**2 - self.Lfd**2


	def look_ahead_pt(self, frame):
		center_pts = np.zeros([2,10])
		for i in range(10):
			temp = np.nonzero(frame[i*40:i*40+39,:])
			xl = np.sum(temp[1])/len(temp[1])
			center_pts[0][i] = xl
			center_pts[1][i] = i*40 + 20
			self.z = np.polyfit(center_pts[1], center_pts[0], 2)
			sol = optimize.root(self.func, [0,0])
		x1 = self.z[0]*sol.x[0]**2 + self.z[1]*sol.x[0] + self.z[2]
		x2 = self.z[0]*sol.x[1]**2 + self.z[1]*sol.x[1] + self.z[2]
		if(x1 > 0 and x1 < 400 and sol.x[0] > 0 and sol.x[0] < 400):
			return [x1, sol.x[0]]
		elif(x2 > 0 and x2 < 400 and sol.x[1] > 0 and sol.x[1] < 400):
			return [x2, sol.x[1]]


	def steering_angle(self, pt):
		if pt is not None:
			if pt[0] != 200:
				alpha = np.arctan2(pt[1] - self.pw + 1, pt[0] - self.ph/2 + 1) - math.pi/2
				delta = np.arctan2(2*self.L*np.sin(alpha )/self.Lfd/0.217, 1) # 0.217 cm/pixel
				return delta
			else:
				return 0

	#def center_deviation(self, frame):
		
