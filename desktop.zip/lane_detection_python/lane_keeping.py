#!/usr/bin/env python
import rospy
import cv2
import numpy as np
from lane_detection import lane_detection
from sensor_msgs.msg import Joy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge

# Initialize lane_detection
ld = lane_detection(binary_low_thr = 230)

# Initialize CvBridge
bridge = CvBridge()

# Initialize global publisher
pub = rospy.Publisher('/vesc/joy', Joy, queue_size = 1)

DIM = (1920, 1080)
dim2 = (1920,1080)
dim3 = (1920,1080)
balance = 1
K = np.array([[797.291347853076, 0.0, 954.0911522248246], [0.0, 797.7486635926731, 524.5785087770129], [0.0, 0.0, 1.0]])
Knew = K.copy()
Knew[(0,1),(0,1)] = 0.4*Knew[(0,1),(0,1)]
D = np.array([[-0.022046185426876273], [-0.0014811900456108225], [-0.002085499019587609], [0.0005973311977065658]])


'''
# Functino to un-distort fisheye
def undistort(frame, balance=0.0, dim2=None, dim3=None):
    dim1 = frame.shape[:2][::-1]  #dim1 is the dimension of input image to un-distort
    assert dim1[0]/dim1[1] == DIM[0]/DIM[1], "Image to undistort needs to have same aspect ratio as the ones used in calibration"
    if not dim2:
        dim2 = dim1
    if not dim3:
        dim3 = dim1
    scaled_K = K * dim1[0] / DIM[0]  # The values of K is to scale with image dimension.
    scaled_K[2][2] = 1.0  # Except that K[2][2] is always 1.0
    # This is how scaled_K, dim2 and balance are used to determine the final K used to un-distort image. OpenCV document failed to make this clear!
    new_K = cv2.fisheye.estimateNewCameraMatrixForUndistortRectify(scaled_K, D, dim2, np.eye(3), balance=balance)
    map1, map2 = cv2.fisheye.initUndistortRectifyM+ap(scaled_K, D, np.eye(3), new_K, dim3, cv2.CV_16SC2)
    undistorted_frame = cv2.remap(frame, map1, map2, interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)
    return undistorted_frame
'''


def lane_fit(frame):
	frame_undis = cv2.fisheye.undistortImage(frame, K, D=D, Knew=Knew)
	lane_region = ld.perspective_transform(frame_undis)
	#lane = ld.convert_binary_image(frame)
	lane_edge = ld.canny_frame(lane_region)
	pt = ld.look_ahead_pt(lane_edge)
	delta = ld.steering_angle(pt)

	#cv2.imshow("Front Camera", frame_undis)
	#cv2.waitKey(10)

	return delta

def cb(msg):
	global pub
	new_msg = Joy()
	new_msg.header.stamp = rospy.Time.now()
	new_msg.axes = [0.0]*6
	new_msg.buttons = [0.0]*25
	frame = bridge.imgmsg_to_cv2(msg, "bgr8")
	new_msg.axes[0] = lane_fit(frame)
	new_msg.axes[2] = 1000
	pub.publish(new_msg)

if __name__ == '__main__':
	rospy.init_node('lane_keeping', anonymous=True)
	rospy.Subscriber("/front_cam/fisheye_raw", Image, cb)
	rospy.spin()
