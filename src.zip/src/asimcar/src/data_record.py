#!/usr/bin/env python
import rospy
from sensor_msgs.msg import Imu

f = open("imu_data.txt", "w")

def callback(data):
    #f.write(repr(data.linear_acceleration.x) + " " + repr(data.linear_acceleration.y) + " " + repr(data.linear_acceleration.z) + "\n")
    f.write(repr(data.angular_velocity.x) + " " + repr(data.angular_velocity.y) + " " + repr(data.angular_velocity.z) + "\n")
    
def recorder():
    rospy.init_node('recorder', anonymous=True)
    rospy.Subscriber("/imu/data_raw", Imu, callback)
    rospy.spin()

if __name__ == '__main__':
    try:
        recorder()
    except rospy.ROSInterruptException:
        f.close()
