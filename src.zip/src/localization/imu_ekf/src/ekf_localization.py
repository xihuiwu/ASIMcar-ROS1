#!/usr/bin/env python
import numpy as np
import math
import rospy
from std_msgs.msg import Float64
from sensor_msgs.msg import Imu
from geometry_msgs.msg import Pose2D
from bicycle_msgs.msg import BicyclePoseStamped
from vesc_msgs.msg import VescStateStamped

class ekf_localization:
	def __init__(self):
		# initialize variable for usage
		self.steering = 0.0
		self.acce = 0.0
		self.pre_time = rospy.Time.now()
		self.gps_flag = rospy.get_param("gps_flag")
		self.wheelbase = rospy.get_param("/vesc/wheelbase")
		self.lf = rospy.get_param("/vesc/lf")
		self.lr = rospy.get_param("/vesc/lr")
		procCov = rospy.get_param("procCov")
		stateCov = rospy.get_param("stateCov")
		acceCovx = rospy.get_param("/imu_driver/acce_cov/x")
		angularCovz = rospy.get_param("/imu_driver/angular_cov/z")

		self.gps_sub = rospy.Subscriber("gps", Pose2D, self.gpsCallback)
		self.acce_sub = rospy.Subscriber("/vesc/sensors/core", VescStateStamped, self.acceCallback)
		self.steering_sub = rospy.Subscriber("/vesc/sensors/servo_position_command", Float64, self.acceCallback)
		self.imu_sub = rospy.Subscriber("/imu/data", Imu, self.imuCallback)
		self.pose_pub = rospy.Publisher("/asimcar/state", BicyclePoseStamped, queue_size=1)

		self.gps = np.zeros(shape=(2,1))
		self.state = np.zeros(shape=(4,1))
		self.state_tilde = np.zeros(shape=(4,1))
		

		self.P = stateCov*np.eye(4)
		self.Q = procCov*np.eye(4)
		self.S = np.zeros(shape=(4,4))
		self.K = np.zeros(shape=(4,4))

		if self.gps_flag == 1:
			self.state[0] = self.gps[0]
			self.state[1] = self.gps[1]
			gpsCov = rospy.get_param("gpsCov")
			self.R = np.diag([gpsCov[0], gpsCov[1], angularCovz, acceCovx])
			self.H = np.diag([1, 1, 1, 1])
		else:
			self.R = np.diag([0, 0, angularCovz, acceCovx])
			self.H = np.diag([0, 0, 1, 1])

		self.pose_msg = BicyclePoseStamped()

		self.run()

	def run(self):
		rospy.spin()

	def gpsCallback(self, gps_msg):
		self.gps[0] = gps_msg.x
		self.gps[1] = gps_msg.y

	def acceCallback(self, vesc_msg):
		self.acce = vesc_msg.state.current_input

	def steeringCallback(self, steering_msg):
		self.steering = steering_msg.data

	def imuCallback(self, imu_msg):
		time = rospy.Time.now()
		duration = time - self.pre_time
		dt = duration.nsecs/1e8
		self.pre_time = time

		# prediction
		self.state[0] = self.state[0] + self.state[3]*math.cos(self.state[2])*dt
		self.state[1] = self.state[1] + self.state[3]*math.sin(self.state[2])*dt
		beta = math.atan(self.lr/self.wheelbase*math.tan(self.steering))
		self.state[2] = self.state[2] + self.state[3]/self.lr*math.sin(beta)
		self.state[3] = self.state[3] + self.acce*dt
		self.F = [[1, 0, float(self.state[3]*math.sin(self.state[2])*dt), math.cos(self.state[2])*dt],
		          [0, 1, float(self.state[3]*math.cos(self.state[2])*dt), math.sin(self.state[2])*dt],
		          [0, 0, 1, math.tan(self.steering)/self.wheelbase*dt],
		          [0, 0, 0, 1]]
		self.P = np.matmul(np.matmul(self.F, self.P), np.transpose(self.F)) + self.Q

		# correction
		if self.gps_flag == 1:
			self.state_tilde = [[self.gps[0]-self.state[0]],
			                    [self.gps[1]-self.state[1]],
			                    [imu_msg.angular_velocity.z*dt],
			                    [imu_msg.linear_acceleration.x*dt]]
		else:
			self.state_tilde = [[0],
			                    [0],
			                    [imu_msg.angular_velocity.z*dt],
			                    [imu_msg.linear_acceleration.x*dt]]
		self.S = np.matmul(np.matmul(self.H, self.P), np.transpose(self.H)) + self.R
		self.K = np.matmul(np.matmul(self.P, self.H), np.transpose(self.S))
		self.state = self.state + np.matmul(self.K, self.state_tilde)
		self.P = np.matmul((np.eye(4) - np.matmul(self.K, self.H)), self.P)

		self.pose_msg.header.stamp = time
		self.pose_msg.pose.x = self.state[0]
		self.pose_msg.pose.y = self.state[1]
		self.pose_msg.pose.theta = self.state[2]
		self.pose_msg.pose.speed = self.state[3]

		self.pose_pub.publish(self.pose_msg)

if __name__ == "__main__":
	rospy.init_node('ekf_localization', anonymous=True)
	try:
		localization = ekf_localization()
	except rospy.ROSInterruptException:
		pass
