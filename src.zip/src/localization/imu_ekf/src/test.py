#!/usr/bin/env python
import numpy as np
import math


if __name__ == "__main__":
	steering = 0.05
	acce = 0.5
	wheelbase = 0.256
	lf = 0.128
	lr = 0.128

	state = np.zeros(shape=(4,1))
	state_tilde = np.zeros(shape=(4,1))

	P = 0.1*np.eye(4)
	Q = 0.01*np.eye(4)
	R = np.diag([0, 0, 0.0001, 0.0001])
	H = np.diag([0, 0, 1, 1])
	S = np.zeros(shape=(4,4))
	K = np.zeros(shape=(4,4))
	
	dt = 0.1
	
	# prediction
	state[0] = state[0] + state[3]*math.cos(state[2])*dt
	print(state[0])
	state[1] = state[1] + state[3]*math.sin(state[2])*dt
	print(state[1])
	beta = math.atan(lr/wheelbase*math.tan(steering))
	print(beta)
	state[2] = state[2] + state[3]/lr*math.sin(beta)
	print(state[2])
	state[3] = state[3] + acce*dt
	print(np.asscalar(state[3]*math.sin(state[2])*dt))
	F = [[1, 0, float(state[3]*math.sin(state[2])*dt), float(math.cos(state[2])*dt)],
	          [0, 1, float(state[3]*math.cos(state[2])*dt), float(math.sin(state[2])*dt)],
	          [0, 0, 1, math.tan(steering)/wheelbase*dt],
	          [0, 0, 0, 1]]
	print(F)
	temp = np.matmul(F, P)
	P = np.matmul(temp, np.transpose(F)) + Q

	# correction
	state_tilde = [[0],
                   [0],
                   [0.0001*dt],
                   [0.0001*dt]]
	S = np.matmul(np.matmul(H, P), np.transpose(H)) + R
	temp = np.matmul(P, H)
	K = np.matmul(temp, np.transpose(S))
	state = state + np.matmul(K, state_tilde)
	P = np.matmul((np.eye(4) - np.matmul(K, H)), P)
